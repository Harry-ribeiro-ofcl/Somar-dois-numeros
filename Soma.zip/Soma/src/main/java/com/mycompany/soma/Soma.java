/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.soma;

/**
 *
 * @author Vagner Fernando
 */
import javax.swing.JOptionPane;
public class Soma {

    public static void main(String[] args) {
        String Pri = JOptionPane.showInputDialog("Digite o primeiro numero");
        String Seg = JOptionPane.showInputDialog("Digite o segundo numero");
        
        int num1 = Integer.parseInt(Pri);
        int num2 = Integer.parseInt(Seg);
        
        int soma = num1 + num2;
        
        JOptionPane.showMessageDialog(null, "A soma é: "+ soma, "Resultado da Soma", JOptionPane.PLAIN_MESSAGE);
    }
}
